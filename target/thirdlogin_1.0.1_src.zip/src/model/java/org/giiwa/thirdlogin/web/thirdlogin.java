package org.giiwa.thirdlogin.web;

import org.giiwa.framework.web.Model;
import org.giiwa.framework.web.Path;

public class thirdlogin extends Model{

  @Path()
  public void onGet() {
    
  }
  
}
